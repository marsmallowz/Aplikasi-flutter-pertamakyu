import 'package:cobaaaa_dulu/app/sign_in/sign_in_button.dart';
import 'package:cobaaaa_dulu/services/auth.dart';
import 'package:flutter/material.dart';

class SignInPage extends StatelessWidget {
//  final TextEditingController _emailController = TextEditingController();
//  final TextEditingController _passwordController = TextEditingController();
//
//  void _submit() {
//    print('email${_emailController}, password${_passwordController}');
//  }
  SignInPage({@required this.auth});
  final AuthBase auth;
  Future<void> _signInAnonymously() async {
    try {
      await auth.signAnonymously();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> _signInWithGoogle() async {
    try {
      await auth.signInWithGoogle();
    } catch (e) {
      print(e.toString());
    }
  }

  Future<void> _signInWithFacebook() async {
    try {
      await auth.signInWithFacebook();
    } catch (e) {
      print(e.toString());
    }
  }

  double getSmallDiameter(BuildContext context) =>
      MediaQuery.of(context).size.width * 2 / 3;
  double getBigDiameter(BuildContext context) =>
      MediaQuery.of(context).size.width * 7 / 8;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[110],
      body: buildStack(context),
    );
  }

  Widget buildStack(BuildContext context) {
    return Stack(
      children: <Widget>[
        Positioned(
          right: -getSmallDiameter(context) / 3,
          top: -getSmallDiameter(context) / 3,
          child: Container(
            width: getSmallDiameter(context),
            height: getSmallDiameter(context),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                  colors: [Colors.cyanAccent, Colors.green],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter),
            ),
          ),
        ),
        Positioned(
          top: -getBigDiameter(context) / 5,
          left: -getBigDiameter(context) / 4,
          child: Container(
            child: Center(
              child: Text(
                "Log In",
                style: TextStyle(
                    fontFamily: "earwig", color: Colors.white, fontSize: 50),
              ),
            ),
            height: getBigDiameter(context),
            width: getBigDiameter(context),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [Colors.cyanAccent, Colors.green],
                end: Alignment.bottomCenter,
                begin: Alignment.topCenter,
              ),
            ),
          ),
        ),
        Positioned(
          right: -getBigDiameter(context) / 2,
          bottom: -getBigDiameter(context) / 2,
          child: Container(
            height: getBigDiameter(context),
            width: getBigDiameter(context),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                  colors: [Colors.green, Colors.greenAccent],
                  end: Alignment.bottomCenter,
                  begin: Alignment.topCenter),
            ),
          ),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: ListView(
            children: <Widget>[
              Container(
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(5)),
                margin: EdgeInsets.fromLTRB(20, 300, 10, 10),
                padding: EdgeInsets.fromLTRB(10, 0, 10, 25),
                child: Column(
                  children: <Widget>[
                    TextField(
                      decoration: InputDecoration(
                          icon: Icon(Icons.email, color: Colors.greenAccent),
                          focusedBorder: UnderlineInputBorder(
                              borderSide:
                                  BorderSide(color: Colors.greenAccent)),
                          labelText: "Email",
                          labelStyle: TextStyle(color: Colors.greenAccent)),
//                        controller: _emailController,
                    ),
                    TextField(
//                        controller: _passwordController,
                      obscureText: true,
                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.vpn_key,
                          color: Colors.greenAccent,
                        ),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.greenAccent)),
                        labelStyle: TextStyle(color: Colors.greenAccent),
                        labelText: "Password",
                      ),
                    )
                  ],
                ),
              ),
              Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 10, 20),
                    child: Text(
                      "Forget Passowrd ?",
                      style: TextStyle(color: Colors.greenAccent, fontSize: 14),
                    ),
                  )),
              Container(
                margin: EdgeInsets.fromLTRB(20, 0, 20, 30),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.5,
                      height: 40,
                      child: Container(
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(20),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(20),
                            splashColor: Colors.green,
                            onTap: () {},
                            child: Center(
                              child: Text(
                                "Log In",
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w700),
                              ),
                            ),
                          ),
                        ),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            gradient: LinearGradient(
                                colors: [Colors.greenAccent, Colors.green],
                                end: Alignment.bottomCenter,
                                begin: Alignment.topCenter)),
                      ),
                    ),
                    SignInButton(
                      onPressed: _signInWithFacebook,
                      elevation: 0,
                      text: "fonts/logo-fb-2.png",
                    ),
                    FloatingActionButton(
                      onPressed: _signInWithGoogle,
                      mini: true,
                      elevation: 0,
                      child: Image(
                        image: AssetImage("fonts/google-logo.png"),
                      ),
                    )
                  ],
                ),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Text("Dont Have Account?"),
                    Text(
                      "    Register",
                      style: TextStyle(color: Colors.greenAccent),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Center(
                child: RaisedButton(
                  child: Text("Guest"),
                  onPressed: _signInAnonymously,
                ),
              )
            ],
          ),
        ),
      ],
    );
  }
}
